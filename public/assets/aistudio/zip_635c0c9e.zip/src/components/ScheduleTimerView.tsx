import React, { useState, useEffect, useRef } from 'react';
import { PlanItem, UserPreferences } from '../types';
import { soundHelper } from '../utils/soundHelper';

interface ScheduleTimerViewProps {
  plans: PlanItem[];
  selectedPlanId?: string;
  preferences: UserPreferences;
  onToggleBlockCompletion: (planId: string, dayNumber: number, blockId: string) => void;
}

export const ScheduleTimerView: React.FC<ScheduleTimerViewProps> = ({
  plans,
  selectedPlanId,
  preferences,
  onToggleBlockCompletion,
}) => {
  const [activePlanId, setActivePlanId] = useState<string>(
    selectedPlanId || (plans.length > 0 ? plans[0].id : '')
  );

  const activePlan = plans.find((p) => p.id === activePlanId) || plans[0];

  // Timer States
  const [timerMode, setTimerMode] = useState<'focus' | 'break'>('focus');
  const [durationMinutes, setDurationMinutes] = useState<number>(45); // default 45 min cognitive block
  const [timeLeft, setTimeLeft] = useState<number>(45 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [completedSessions, setCompletedSessions] = useState<number>(0);
  const [showEyeBreakModal, setShowEyeBreakModal] = useState<boolean>(false);

  const timerRef = useRef<any>(null);

  // Switch timer presets
  const handleSetPreset = (focusMin: number, breakMin: number) => {
    setIsRunning(false);
    if (timerMode === 'focus') {
      setDurationMinutes(focusMin);
      setTimeLeft(focusMin * 60);
    } else {
      setDurationMinutes(breakMin);
      setTimeLeft(breakMin * 60);
    }
    soundHelper.playChime('click');
  };

  // Timer Tick
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            handleTimerComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, timerMode]);

  const handleTimerComplete = () => {
    setIsRunning(false);
    if (timerMode === 'focus') {
      soundHelper.playChime('break');
      soundHelper.speakThaiReminder('break', preferences.voiceStyle);
      setCompletedSessions((prev) => prev + 1);
      setShowEyeBreakModal(true);
      // Auto switch to break mode
      setTimerMode('break');
      setDurationMinutes(15);
      setTimeLeft(15 * 60);
    } else {
      soundHelper.playChime('complete');
      soundHelper.speakThaiReminder('focus', preferences.voiceStyle);
      setTimerMode('focus');
      setDurationMinutes(45);
      setTimeLeft(45 * 60);
    }
  };

  const handleTogglePlay = () => {
    const nextState = !isRunning;
    setIsRunning(nextState);
    if (nextState) {
      soundHelper.playChime('start');
      soundHelper.speakThaiReminder('focus', preferences.voiceStyle);
    } else {
      soundHelper.playChime('click');
    }
  };

  const handleResetTimer = () => {
    setIsRunning(false);
    setTimeLeft(durationMinutes * 60);
    soundHelper.playChime('click');
  };

  // Format time mm:ss
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progressRatio = durationMinutes > 0 ? (timeLeft / (durationMinutes * 60)) : 0;

  if (plans.length === 0) {
    return (
      <div className="w-full py-16 text-center flex flex-col items-center gap-3">
        <span className="material-symbols-outlined text-[48px] text-on-surface-variant">schedule</span>
        <h2 className="font-headline-md text-lg font-bold text-on-surface">ยังไม่มีตารางเวลาในระบบ</h2>
        <p className="text-xs text-on-surface-variant">
          โปรดสร้างแผนโดยการเพิ่มหัวข้อสอบหรือหัวข้อการบ้านในแท็บ &quot;อัปโหลด &amp; วิเคราะห์&quot; ก่อน
        </p>
      </div>
    );
  }

  return (
    <div className="w-full py-6 flex flex-col gap-6 animate-fadeIn">
      {/* Eye Rest / Wellness Break Modal */}
      {showEyeBreakModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-surface-container-lowest max-w-md w-full p-6 md:p-8 rounded-3xl border border-subtle shadow-xl flex flex-col items-center text-center gap-4">
            <div className="w-16 h-16 rounded-full bg-primary-fixed text-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-[36px]">visibility</span>
            </div>
            <div className="flex flex-col gap-1">
              <h3 className="font-headline-md text-lg md:text-xl font-bold text-on-surface">
                ถึงเวลาพักสายตาและฟื้นฟูสมอง!
              </h3>
              <p className="font-body-md text-xs md:text-sm text-on-surface-variant">
                คุณอ่านหนังสือ/ทำงานอย่างมีสมาธิครบกำหนดแล้ว ตามกฎ 20-20-20 สุขภาพสายตาของคุณสำคัญที่สุด
              </p>
            </div>

            <div className="w-full p-4 rounded-2xl bg-surface-container-low border border-subtle flex flex-col gap-2 text-left text-xs text-on-surface">
              <div className="flex items-center gap-2">
                <span className="text-primary font-bold">🌿</span>
                <span>มองออกไปที่วัตถุหรือต้นไม้ไกล 20 ฟุต (6 เมตร) นิ่งๆ 20 วินาที</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-secondary font-bold">💧</span>
                <span>จิบน้ำเปล่า 1 แก้วเต็ม เพื่อให้สมองไม่ขาดน้ำ</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-tertiary-container font-bold">🧘</span>
                <span>หมุนหัวไหล่ คลายกล้ามเนื้อคอบ่า 5-10 ครั้ง</span>
              </div>
            </div>

            <button
              onClick={() => setShowEyeBreakModal(false)}
              className="w-full py-3 rounded-full bg-primary text-white font-label-md text-xs md:text-sm font-semibold cursor-pointer shadow-md hover:bg-primary/90 transition-all"
            >
              รับทราบ เริ่มช่วงเวลาพัก 15 นาที
            </button>
          </div>
        </div>
      )}

      {/* Top Banner & Plan Picker */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface-container-lowest p-6 rounded-2xl border border-subtle shadow-xs">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2 text-secondary">
            <span className="material-symbols-outlined text-[20px]">timer</span>
            <span className="font-label-lg font-bold text-sm">ตารางเวลา &amp; ตัวจับเวลาอัจฉริยะ</span>
          </div>
          <h1 className="font-headline-md text-xl md:text-2xl font-bold text-on-surface">
            จัดสรรเวลาตามหลักสุขภาวะ (Cognitive Balance)
          </h1>
          <p className="font-body-sm text-xs text-on-surface-variant">
            ฝึกสมาธิด้วยตัวจับเวลาแบบแบ่งช่วง และทำเครื่องหมายช่วงเวลาที่เสร็จแล้ว
          </p>
        </div>

        {/* Plan Switcher Dropdown */}
        <div className="flex items-center gap-2 bg-surface-container-low px-3 py-1.5 rounded-xl border border-subtle">
          <span className="text-xs text-on-surface-variant font-medium">วิชาที่เลือก:</span>
          <select
            value={activePlanId}
            onChange={(e) => setActivePlanId(e.target.value)}
            className="bg-transparent text-xs font-semibold text-on-surface focus:outline-none cursor-pointer"
          >
            {plans.map((p) => (
              <option key={p.id} value={p.id}>
                {p.type === 'exam' ? '📝 สอบ: ' : '📚 การบ้าน: '}
                {p.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid: Pomodoro Focus Timer + Daily Schedule Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 Cols): Built-in Pomodoro Study Timer */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="bg-surface-container-lowest p-6 rounded-3xl border border-subtle shadow-sm flex flex-col items-center text-center gap-5">
            {/* Mode Switcher */}
            <div className="flex items-center gap-1 bg-surface-container-low p-1 rounded-full border border-subtle w-full max-w-xs">
              <button
                onClick={() => {
                  setTimerMode('focus');
                  setIsRunning(false);
                  setTimeLeft(45 * 60);
                  setDurationMinutes(45);
                  soundHelper.playChime('click');
                }}
                className={`flex-1 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  timerMode === 'focus'
                    ? 'bg-primary text-white shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                ช่วงโฟกัส (45m)
              </button>
              <button
                onClick={() => {
                  setTimerMode('break');
                  setIsRunning(false);
                  setTimeLeft(15 * 60);
                  setDurationMinutes(15);
                  soundHelper.playChime('click');
                }}
                className={`flex-1 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  timerMode === 'break'
                    ? 'bg-tertiary-container text-white shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                พักฟื้นสายตา (15m)
              </button>
            </div>

            {/* Circular Timer Visual Display */}
            <div className="relative w-52 h-52 md:w-60 md:h-60 rounded-full flex flex-col items-center justify-center p-4">
              {/* Outer Ring */}
              <svg className="absolute inset-0 w-full h-full -rotate-90">
                <circle
                  cx="50%"
                  cy="50%"
                  r="44%"
                  className="stroke-surface-container-low fill-none"
                  strokeWidth="8"
                />
                <circle
                  cx="50%"
                  cy="50%"
                  r="44%"
                  className={`fill-none transition-all duration-500 ${
                    timerMode === 'focus' ? 'stroke-primary' : 'stroke-tertiary-container'
                  }`}
                  strokeWidth="8"
                  strokeDasharray="276"
                  strokeDashoffset={276 * (1 - progressRatio)}
                  strokeLinecap="round"
                />
              </svg>

              <span className="font-code-badge text-3xl md:text-4xl font-bold tracking-tight text-on-surface">
                {formatTime(timeLeft)}
              </span>

              <span className="text-xs text-on-surface-variant font-medium mt-1">
                {timerMode === 'focus' ? '🎯 กำลังโฟกัสเนื้อหา' : '🌿 พักสายตาและผ่อนคลาย'}
              </span>

              {/* Status Indicator */}
              <div className="flex items-center gap-1.5 mt-2 bg-surface-container-low px-2.5 py-0.5 rounded-full text-[11px] text-on-surface-variant">
                <div
                  className={`w-2 h-2 rounded-full ${
                    isRunning ? 'bg-primary-container animate-pulse' : 'bg-on-surface-variant/40'
                  }`}
                />
                <span>{isRunning ? 'กำลังจับเวลา' : 'หยุดชั่วคราว'}</span>
              </div>
            </div>

            {/* Play/Pause & Reset Controls */}
            <div className="flex items-center gap-3">
              <button
                onClick={handleResetTimer}
                className="w-12 h-12 rounded-full bg-surface-container-low text-on-surface hover:bg-surface-container border border-subtle flex items-center justify-center transition-colors cursor-pointer"
                title="รีเซ็ตตัวจับเวลา"
              >
                <span className="material-symbols-outlined text-[20px]">refresh</span>
              </button>

              <button
                onClick={handleTogglePlay}
                className={`px-8 py-3.5 rounded-full text-white font-label-lg text-sm md:text-base font-bold shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-95 ${
                  timerMode === 'focus'
                    ? 'bg-gradient-to-r from-primary to-primary-container shadow-primary/20'
                    : 'bg-gradient-to-r from-tertiary-container to-amber-500 shadow-amber-500/20'
                }`}
              >
                <span className="material-symbols-outlined text-[24px]">
                  {isRunning ? 'pause' : 'play_arrow'}
                </span>
                <span>{isRunning ? 'พักการจับเวลา' : 'เริ่มจับเวลา'}</span>
              </button>

              <button
                onClick={() => {
                  soundHelper.playChime('break');
                  soundHelper.speakThaiReminder('break', preferences.voiceStyle);
                }}
                className="w-12 h-12 rounded-full bg-surface-container-low text-primary hover:bg-surface-container border border-subtle flex items-center justify-center transition-colors cursor-pointer"
                title="ทดสอบฟังเสียงเตือนใจ"
              >
                <span className="material-symbols-outlined text-[20px]">volume_up</span>
              </button>
            </div>

            {/* Presets Quick Buttons */}
            <div className="flex items-center justify-center gap-2 pt-1 border-t border-subtle w-full text-xs">
              <span className="text-on-surface-variant">พรีเซ็ต:</span>
              <button
                onClick={() => handleSetPreset(25, 5)}
                className="px-2.5 py-1 rounded-lg bg-surface-container-low hover:bg-surface-container text-on-surface font-code-badge border border-subtle cursor-pointer"
              >
                25 / 5m
              </button>
              <button
                onClick={() => handleSetPreset(45, 15)}
                className="px-2.5 py-1 rounded-lg bg-primary-fixed text-primary font-code-badge font-bold border border-primary/30 cursor-pointer"
              >
                45 / 15m (แนะนำ)
              </button>
              <button
                onClick={() => handleSetPreset(60, 15)}
                className="px-2.5 py-1 rounded-lg bg-surface-container-low hover:bg-surface-container text-on-surface font-code-badge border border-subtle cursor-pointer"
              >
                60 / 15m
              </button>
            </div>

            {/* Completed Sessions Counter */}
            <div className="flex items-center justify-between w-full p-3 rounded-xl bg-surface-container-low text-xs text-on-surface border border-subtle">
              <span>ช่วงเวลาโฟกัสที่เสร็จสิ้นวันนี้:</span>
              <span className="font-code-badge font-bold text-primary">
                {completedSessions} ช่วง (~{(completedSessions * 45) / 60} ชม.)
              </span>
            </div>
          </div>
        </div>

        {/* Right Column (7 Cols): Interactive Daily Schedule */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="bg-surface-container-lowest p-6 rounded-3xl border border-subtle shadow-sm flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <span className="font-headline-sm text-base md:text-lg font-bold text-on-surface flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-[22px]">calendar_today</span>
                ตารางเวลาแบ่งเรียน/การบ้านต่อวัน
              </span>
              <span className="text-xs text-on-surface-variant font-code-badge">
                {activePlan.dailySchedule.length} วัน • ติ๊กเมื่อทำเสร็จ
              </span>
            </div>

            <div className="flex flex-col gap-4">
              {activePlan.dailySchedule.map((day) => (
                <div
                  key={day.dayNumber}
                  className="p-4 rounded-2xl bg-surface-container-low border border-subtle flex flex-col gap-3"
                >
                  <div className="flex items-center justify-between border-b border-subtle pb-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-primary text-white font-code-badge text-xs flex items-center justify-center font-bold">
                        {day.dayNumber}
                      </span>
                      <span className="font-label-md text-xs md:text-sm font-bold text-on-surface">
                        {day.dateLabel}
                      </span>
                    </div>
                    <span className="text-xs text-on-surface-variant font-code-badge">
                      เป้าหมาย: <strong className="text-primary">{day.focusGoal}</strong>
                    </span>
                  </div>

                  {/* Day Blocks */}
                  <div className="flex flex-col gap-2">
                    {day.blocks.map((block) => (
                      <div
                        key={block.id}
                        onClick={() =>
                          onToggleBlockCompletion(activePlan.id, day.dayNumber, block.id)
                        }
                        className={`p-3 rounded-xl border transition-all cursor-pointer flex items-start justify-between gap-3 text-xs ${
                          block.completed
                            ? 'bg-primary-fixed/15 border-primary/40 opacity-75'
                            : block.type === 'break'
                            ? 'bg-tertiary-container/10 border-tertiary-container/30 hover:border-tertiary-container'
                            : 'bg-surface-container-lowest border-subtle hover:border-primary/40'
                        }`}
                      >
                        <div className="flex items-start gap-2.5">
                          <div
                            className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center border transition-all ${
                              block.completed
                                ? 'bg-primary border-primary text-white'
                                : 'border-subtle bg-surface-container-lowest'
                            }`}
                          >
                            {block.completed && <span className="text-[10px] font-bold">✓</span>}
                          </div>

                          <div className="flex flex-col gap-0.5">
                            <div className="flex items-center gap-2">
                              <span className="font-code-badge font-bold text-primary text-xs">
                                {block.timeSlot}
                              </span>
                              <span
                                className={`font-semibold ${
                                  block.completed ? 'line-through text-on-surface-variant' : 'text-on-surface'
                                }`}
                              >
                                {block.title}
                              </span>
                            </div>

                            {block.wellnessTip && (
                              <span className="text-[11px] text-tertiary-container font-medium flex items-center gap-1 mt-0.5">
                                <span className="material-symbols-outlined text-[13px]">eco</span>
                                {block.wellnessTip}
                              </span>
                            )}
                          </div>
                        </div>

                        <span
                          className={`font-code-badge text-[10px] px-2 py-0.5 rounded-full shrink-0 font-medium ${
                            block.type === 'break'
                              ? 'bg-tertiary-container text-white'
                              : block.type === 'review'
                              ? 'bg-secondary text-white'
                              : 'bg-primary-fixed text-primary'
                          }`}
                        >
                          {block.type === 'break' ? 'พักสายตา' : block.type === 'review' ? 'ทบทวน' : 'อ่าน/ทำ'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
