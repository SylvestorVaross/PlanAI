import React from 'react';
import { PlanItem, UserPreferences } from '../types';
import { soundHelper } from '../utils/soundHelper';

interface DashboardViewProps {
  plans: PlanItem[];
  preferences: UserPreferences;
  onOpenWizard: (type?: 'exam' | 'homework') => void;
  onSelectPlan: (planId: string, view: 'summary' | 'schedule') => void;
  onDeletePlan: (planId: string) => void;
  onClearAllPlans?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  plans,
  preferences,
  onOpenWizard,
  onSelectPlan,
  onDeletePlan,
  onClearAllPlans,
}) => {
  const examCount = plans.filter((p) => p.type === 'exam').length;
  const hwCount = plans.filter((p) => p.type === 'homework').length;

  const totalTopics = plans.reduce((acc, p) => acc + (p.topics ? p.topics.length : 0), 0);
  const completedTopics = plans.reduce(
    (acc, p) => acc + (p.topics ? p.topics.filter((t) => t.completed).length : 0),
    0
  );
  const progressPercent = totalTopics > 0 ? Math.round((completedTopics / totalTopics) * 100) : 0;

  return (
    <div className="w-full py-6 flex flex-col gap-6 animate-fadeIn">
      {/* Welcome & Motivation Banner */}
      <div className="relative overflow-hidden bg-surface-container-lowest p-6 md:p-8 rounded-3xl shadow-sm border border-subtle flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4 z-10">
          <img
            alt={preferences.userName}
            src={preferences.avatarUrl}
            className="w-16 h-16 md:w-20 md:h-20 rounded-2xl object-cover ring-4 ring-primary/20 shadow-sm"
          />
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <span className="font-headline-lg text-xl md:text-2xl font-bold text-on-surface">
                สวัสดี {preferences.userName}!
              </span>
              <span className="font-code-badge bg-primary-fixed text-on-primary-fixed px-2.5 py-0.5 rounded-full text-xs font-semibold">
                {preferences.userRole}
              </span>
            </div>
            <p className="font-body-md text-xs md:text-sm text-on-surface-variant max-w-xl">
              ยินดีต้อนรับสู่ PlanAI ระบบวางแผนการเรียนอัจฉริยะที่ใส่ใจสุขภาวะสายตาและสมองของคุณ{' '}
              {plans.length > 0
                ? `วันนี้มี ${plans.length} วิชาในแผน`
                : 'ยังไม่มีวิชาในแผน เริ่มต้นเพิ่มวิชาแรกได้เลย!'}
            </p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap items-center gap-2.5 z-10 w-full md:w-auto">
          <button
            onClick={() => onOpenWizard('exam')}
            className="flex-1 md:flex-initial px-4 py-3 rounded-full bg-primary text-white font-label-md text-xs md:text-sm font-semibold shadow-md hover:bg-primary/90 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">assignment</span>
            <span>+ เพิ่มหัวข้อสอบ</span>
          </button>
          <button
            onClick={() => onOpenWizard('homework')}
            className="flex-1 md:flex-initial px-4 py-3 rounded-full bg-secondary text-white font-label-md text-xs md:text-sm font-semibold shadow-md hover:bg-secondary/90 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">menu_book</span>
            <span>+ เพิ่มหัวข้อการบ้าน</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Plans */}
        <div className="bg-surface-container-lowest p-5 rounded-2xl border border-subtle flex items-center justify-between shadow-xs">
          <div className="flex flex-col">
            <span className="text-xs text-on-surface-variant font-medium">รายการที่กำลังติดตาม</span>
            <span className="text-2xl font-bold text-on-surface font-headline-md mt-1">
              {plans.length} <span className="text-sm font-normal text-on-surface-variant">รายการ</span>
            </span>
            <span className="text-[11px] text-primary mt-1 font-semibold">
              {examCount} สอบ • {hwCount} การบ้าน
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-primary-fixed/30 text-primary flex items-center justify-center">
            <span className="material-symbols-outlined text-[24px]">folder_special</span>
          </div>
        </div>

        {/* Card 2: Cognitive Wellness Score */}
        <div className="bg-surface-container-lowest p-5 rounded-2xl border border-subtle flex items-center justify-between shadow-xs">
          <div className="flex flex-col">
            <span className="text-xs text-on-surface-variant font-medium">คะแนนสุขภาวะสมอง</span>
            <span className="text-2xl font-bold text-primary font-headline-md mt-1">
              98%
            </span>
            <span className="text-[11px] text-on-surface-variant mt-1">
              จัดสรรเวลาพักสายตาสมดุลดี
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-primary-fixed text-primary flex items-center justify-center">
            <span className="material-symbols-outlined text-[24px]">spa</span>
          </div>
        </div>

        {/* Card 3: Overall Topic Progress */}
        <div className="bg-surface-container-lowest p-5 rounded-2xl border border-subtle flex items-center justify-between shadow-xs">
          <div className="flex flex-col flex-1 mr-2">
            <span className="text-xs text-on-surface-variant font-medium">ความคืบหน้าการอ่าน/ทำการบ้าน</span>
            <span className="text-2xl font-bold text-secondary font-headline-md mt-1">
              {progressPercent}%
            </span>
            <div className="w-full bg-surface-container-low h-2 rounded-full overflow-hidden mt-1.5 border border-subtle">
              <div
                className="h-full bg-secondary rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-secondary-fixed text-secondary flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-[24px]">task_alt</span>
          </div>
        </div>

        {/* Card 4: Healthy Eye Breaks */}
        <div className="bg-surface-container-lowest p-5 rounded-2xl border border-subtle flex items-center justify-between shadow-xs">
          <div className="flex flex-col">
            <span className="text-xs text-on-surface-variant font-medium">ระบบเตือนพักสายตา</span>
            <span className="text-sm font-bold text-on-surface mt-1">
              กฎ 20-20-20 ทำงาน
            </span>
            <span className="text-[11px] text-tertiary-container mt-1 font-semibold">
              เสียง: {preferences.voiceStyle === 'friend' ? 'เพื่อนสนิทวัยรุ่น' : preferences.voiceStyle === 'mentor' ? 'พี่รหัสใจดี' : 'เป็นทางการ'}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-tertiary-container/15 text-tertiary-container flex items-center justify-center">
            <span className="material-symbols-outlined text-[24px]">visibility</span>
          </div>
        </div>
      </div>

      {/* Active Plans List */}
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-[22px]">auto_stories</span>
            <h2 className="font-headline-md text-lg md:text-xl font-bold text-on-surface">
              วิชาและกำหนดการที่อยู่ในระบบ ({plans.length})
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-on-surface-variant hidden md:inline">
              คลิกเพื่อดูสรุปผล AI หรือเปิดตารางเวลาตัวจับเวลา
            </span>
            {plans.length > 0 && onClearAllPlans && (
              <button
                type="button"
                onClick={() => {
                  if (confirm('คุณต้องการลบข้อมูลวิชาและแผนการเรียนทั้งหมดใช่หรือไม่? (การกระทำนี้จะลบข้อมูลออกจากระบบ)')) {
                    onClearAllPlans();
                    soundHelper.playChime('click');
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-surface-container-low hover:bg-error/15 text-on-surface-variant hover:text-error text-xs font-semibold transition-colors flex items-center gap-1.5 border border-subtle cursor-pointer"
                title="ล้างข้อมูลวิชาและแผนทั้งหมดออกจากระบบ"
              >
                <span className="material-symbols-outlined text-[16px]">delete_sweep</span>
                <span>ล้างข้อมูลทั้งหมด</span>
              </button>
            )}
          </div>
        </div>

        {plans.length === 0 ? (
          <div className="p-12 text-center bg-surface-container-lowest rounded-3xl border border-subtle flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-surface-container-low flex items-center justify-center text-primary">
              <span className="material-symbols-outlined text-[32px]">post_add</span>
            </div>
            <div className="flex flex-col gap-1 max-w-md">
              <span className="font-headline-sm text-base font-bold text-on-surface">
                ยังไม่มีข้อมูลวิชาในระบบ
              </span>
              <p className="font-body-sm text-xs text-on-surface-variant">
                เริ่มต้นง่ายๆ ด้วยการเลือกว่าจะเพิ่มหัวข้อสอบหรือหัวข้อการบ้าน แล้วส่งไฟล์ให้ AI วิเคราะห์หาวันที่และจัดตารางเวลา
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => onOpenWizard('exam')}
                className="px-5 py-2.5 rounded-full bg-primary text-white text-xs font-semibold cursor-pointer"
              >
                + เพิ่มหัวข้อสอบ
              </button>
              <button
                onClick={() => onOpenWizard('homework')}
                className="px-5 py-2.5 rounded-full bg-secondary text-white text-xs font-semibold cursor-pointer"
              >
                + เพิ่มหัวข้อการบ้าน
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {plans.map((plan) => {
              const isExam = plan.type === 'exam';
              const completedCount = plan.topics.filter((t) => t.completed).length;
              const subPercent = plan.topics.length > 0 ? Math.round((completedCount / plan.topics.length) * 100) : 0;

              return (
                <div
                  key={plan.id}
                  className="p-6 rounded-2xl bg-surface-container-lowest border border-subtle hover:border-primary/50 transition-all shadow-xs flex flex-col justify-between gap-4 group"
                >
                  <div className="flex flex-col gap-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-3 py-1 rounded-full font-code-badge text-xs font-bold flex items-center gap-1 ${
                            isExam
                              ? 'bg-primary-fixed text-on-primary-fixed'
                              : 'bg-secondary-fixed text-secondary'
                          }`}
                        >
                          <span className="material-symbols-outlined text-[14px]">
                            {isExam ? 'assignment' : 'menu_book'}
                          </span>
                          {isExam ? 'หัวข้อสอบ' : 'หัวข้อการบ้าน'}
                        </span>
                        <span className="text-xs text-on-surface-variant bg-surface-container-low px-2.5 py-1 rounded-full border border-subtle">
                          {plan.category}
                        </span>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`คุณต้องการลบ "${plan.title}" ใช่หรือไม่?`)) {
                            onDeletePlan(plan.id);
                          }
                        }}
                        className="text-on-surface-variant hover:text-error p-1 rounded-lg transition-colors cursor-pointer"
                        title="ลบแผนนี้"
                      >
                        <span className="material-symbols-outlined text-[18px]">delete</span>
                      </button>
                    </div>

                    <div className="flex flex-col gap-1">
                      <h3 className="font-headline-sm text-base md:text-lg font-bold text-on-surface group-hover:text-primary transition-colors">
                        {plan.title}
                      </h3>
                      <span className="font-label-sm text-xs text-on-surface-variant">
                        วิชา: <strong className="text-on-surface">{plan.subjectName}</strong>
                      </span>
                    </div>

                    {/* Detected Date Box */}
                    <div className="p-3 rounded-xl bg-surface-container-low border border-subtle flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2 text-on-surface">
                        <span className="material-symbols-outlined text-primary text-[18px]">
                          {isExam ? 'event_note' : 'alarm'}
                        </span>
                        <span>{plan.detectedDate}</span>
                      </div>
                      <span className="font-code-badge text-xs font-bold text-primary bg-primary-fixed/40 px-2 py-0.5 rounded-full">
                        อีก {plan.daysRemaining} วัน
                      </span>
                    </div>

                    {/* Scope Preview */}
                    <p className="font-body-sm text-xs text-on-surface-variant line-clamp-2 leading-relaxed">
                      {plan.summary}
                    </p>

                    {/* Progress Bar */}
                    <div className="flex flex-col gap-1.5 pt-1">
                      <div className="flex items-center justify-between text-xs text-on-surface-variant">
                        <span>ความคืบหน้าหัวข้อ</span>
                        <span className="font-code-badge font-bold text-on-surface">
                          {completedCount}/{plan.topics.length} หัวข้อ ({subPercent}%)
                        </span>
                      </div>
                      <div className="w-full bg-surface-container h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            isExam ? 'bg-primary' : 'bg-secondary'
                          }`}
                          style={{ width: `${subPercent}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Card Bottom Action Buttons */}
                  <div className="flex items-center gap-2 pt-2 border-t border-subtle">
                    <button
                      onClick={() => onSelectPlan(plan.id, 'summary')}
                      className="flex-1 py-2 rounded-xl bg-surface-container-low hover:bg-surface-container text-on-surface font-label-md text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 border border-subtle cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[16px]">subject</span>
                      ดูสรุปผล AI
                    </button>
                    <button
                      onClick={() => onSelectPlan(plan.id, 'schedule')}
                      className={`flex-1 py-2 rounded-xl text-white font-label-md text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs ${
                        isExam ? 'bg-primary hover:bg-primary/90' : 'bg-secondary hover:bg-secondary/90'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[16px]">schedule</span>
                      เปิดตาราง & ตัวจับเวลา
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
