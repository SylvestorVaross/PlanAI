// Sound synthesis & Voice reminder utility for PlanAI

class SoundHelper {
  private audioCtx: AudioContext | null = null;

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  // Play a pleasant chime for timer start/stop/break
  playChime(type: 'start' | 'break' | 'complete' | 'click' = 'complete') {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;

      if (type === 'start') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.25);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (type === 'break') {
        // Soft meditative tone
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.15); // E5
        osc.frequency.setValueAtTime(783.99, now + 0.3); // G5
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
        osc.start(now);
        osc.stop(now + 0.8);
      } else if (type === 'complete') {
        // Uplifting major triad
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.setValueAtTime(739.99, now + 0.18); // F#5
        osc.frequency.setValueAtTime(880.00, now + 0.35); // A5
        gain.gain.setValueAtTime(0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);
        osc.start(now);
        osc.stop(now + 1.2);
      } else {
        // Quick subtle click
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, now);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
        osc.start(now);
        osc.stop(now + 0.08);
      }
    } catch {
      // Audio autoplay policy fallback
    }
  }

  // Voice reminder using browser SpeechSynthesis in Thai
  speakThaiReminder(messageType: 'break' | 'congrats' | 'focus', style: 'friend' | 'mentor' | 'formal' = 'friend') {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    let text = '';
    if (messageType === 'break') {
      if (style === 'friend') {
        text = 'ฮัลโหล! อ่านมา 40 กว่านาทีแล้วนะ พักสายตา ดื่มน้ำสักแก้ว แล้วค่อยลุยต่อนะเพื่อน';
      } else if (style === 'mentor') {
        text = 'น้องครับ ถึงเวลาพักสายตาแล้วนะ หลับตาสัก 2 นาที สมองจะได้แล่นครับ พี่เป็นกำลังใจให้';
      } else {
        text = 'ระบบขอแนะนำให้ท่านพักสายตาและยืดเหยียดร่างกายเพื่อสุขภาพที่ดี';
      }
    } else if (messageType === 'congrats') {
      if (style === 'friend') {
        text = 'สุดยอดเลย! เก็บไปได้อีกหนึ่งหัวข้อแล้ว พักผ่อนให้สบายใจนะ';
      } else if (style === 'mentor') {
        text = 'เก่งมากครับน้อง วันนี้ก้าวหน้าตามแผนได้ดีมาก พักผ่อนให้พอนะครับ';
      } else {
        text = 'ขอแสดงความยินดี คุณได้ทำตามเป้าหมายประจำช่วงเวลานี้สำเร็จแล้ว';
      }
    } else {
      if (style === 'friend') {
        text = 'มาเริ่มลุยกันเลย! สู้ๆ นะ มีสมาธิเต็มที่เพื่อน';
      } else if (style === 'mentor') {
        text = 'พร้อมแล้วเริ่มกันเลยครับน้อง ค่อยๆ ทำทีละขั้น ไม่ต้องกดดัน';
      } else {
        text = 'เริ่มต้นช่วงเวลาโฟกัส ขอให้ตั้งใจอย่างเต็มความสามารถ';
      }
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'th-TH';
      utterance.rate = 1.0;
      utterance.pitch = style === 'friend' ? 1.1 : style === 'mentor' ? 0.95 : 1.0;

      // Find Thai voice if available
      const voices = window.speechSynthesis.getVoices();
      const thaiVoice = voices.find((v) => v.lang.includes('th') || v.lang.includes('TH'));
      if (thaiVoice) {
        utterance.voice = thaiVoice;
      }

      window.speechSynthesis.speak(utterance);
    } catch {
      // Speech synthesis fallback
    }
  }
}

export const soundHelper = new SoundHelper();
