export type TaskType = 'exam' | 'homework';

export interface ExtractedImageData {
  date: string;
  subject: string;
  topics: string[];
}

export interface UploadedFile {
  id: string;
  name: string;
  size: string;
  type: string;
  base64?: string;
  previewUrl?: string;
}

export interface TopicItem {
  id: string;
  title: string;
  subtopics: string[];
  estimatedMinutes: number;
  difficulty: 'ง่าย' | 'ปานกลาง' | 'ยาก' | string;
  technique: string;
  completed?: boolean;
}

export interface ScheduleBlock {
  id: string;
  timeSlot: string;
  title: string;
  type: 'study' | 'break' | 'review';
  wellnessTip?: string;
  completed?: boolean;
}

export interface DailyScheduleDay {
  dayNumber: number;
  dateLabel: string;
  focusGoal: string;
  totalMinutes: number;
  blocks: ScheduleBlock[];
}

export interface PlanItem {
  id: string;
  type: TaskType;
  subjectName: string;
  category: string;
  title: string;
  detectedDate: string;
  daysRemaining: number;
  summary: string;
  keyHighlights: string[];
  recommendedPrepDays: number;
  suggestedDailyHours?: number;
  initialFiles: UploadedFile[];
  detailedFiles: UploadedFile[];
  topics: TopicItem[];
  dailySchedule: DailyScheduleDay[];
  wellnessAdvice: string;
  cognitiveLoadScore?: string;
  createdAt: string;
}

export interface UserPreferences {
  darkMode: boolean;
  highContrast: boolean;
  voiceStyle: 'friend' | 'mentor' | 'formal';
  soundEnabled: boolean;
  userName: string;
  userRole: string;
  avatarUrl: string;
}

export const INITIAL_USER_PREFERENCES: UserPreferences = {
  darkMode: false,
  highContrast: false,
  voiceStyle: 'friend',
  soundEnabled: true,
  userName: 'พิมพ์ชนก',
  userRole: 'นิสิตปี 3',
  avatarUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCt87xn9kzinKH9ugaubEqxih89vDX6s96VVfvvLxvkUdyJwCu5jXBFdklJ3kUORH56jxjJTojxZD5BwliVKBDfdWUSFAfEKYBLDDZAWVWy_sZOdV1UY2w8li7NtJgZE_cGwA6XTJqzOnCejZTqlw3uzwYyY57D5O-TwU3_6xmNANHYKSiHPq3ibvuT6wTDWQHAtSIHG8uDUWdjO2U6d8MNqlksmZyt6zXpAsHNzL8Pj4SgKXasiZSlwA',
};

export const INITIAL_SEED_PLANS: PlanItem[] = [];

