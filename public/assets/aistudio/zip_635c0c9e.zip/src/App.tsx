/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { DashboardView } from './components/DashboardView';
import { WizardView } from './components/WizardView';
import { SummaryView } from './components/SummaryView';
import { ScheduleTimerView } from './components/ScheduleTimerView';
import { AccessibilityModal } from './components/AccessibilityModal';
import {
  PlanItem,
  UserPreferences,
  INITIAL_USER_PREFERENCES,
  INITIAL_SEED_PLANS,
  TaskType,
} from './types';

const STORAGE_KEY_PLANS = 'planai_study_plans_v3';
const STORAGE_KEY_PREFS = 'planai_user_preferences_v2';

export default function App() {
  // Navigation: 'dashboard' | 'wizard' | 'summary' | 'schedule'
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [accessibilityModalOpen, setAccessibilityModalOpen] = useState<boolean>(false);

  // User preferences with LocalStorage
  const [preferences, setPreferences] = useState<UserPreferences>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PREFS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to load preferences from storage:', e);
    }
    return INITIAL_USER_PREFERENCES;
  });

  // Plans data with LocalStorage (defaults to empty array [] and discards mock seed data)
  const [plans, setPlans] = useState<PlanItem[]>(() => {
    try {
      if (typeof window !== 'undefined') {
        // Clean up legacy mock data key if present
        const legacyV2 = localStorage.getItem('planai_study_plans_v2');
        if (legacyV2 && !localStorage.getItem(STORAGE_KEY_PLANS)) {
          try {
            const parsed = JSON.parse(legacyV2);
            if (Array.isArray(parsed)) {
              const userPlansOnly = parsed.filter(
                (p: any) =>
                  p &&
                  p.id &&
                  !p.id.startsWith('plan-seed') &&
                  p.id !== 'plan-seed-1' &&
                  p.id !== 'plan-seed-2' &&
                  p.subjectName !== 'การตลาดดิจิทัล (Digital Marketing 301)' &&
                  p.subjectName !== 'การพัฒนาเว็บแอปพลิเคชัน (Web Dev 202)'
              );
              localStorage.setItem(STORAGE_KEY_PLANS, JSON.stringify(userPlansOnly));
              localStorage.removeItem('planai_study_plans_v2');
              return userPlansOnly;
            }
          } catch {
            localStorage.removeItem('planai_study_plans_v2');
          }
        }
      }

      const saved = localStorage.getItem(STORAGE_KEY_PLANS);
      if (saved) {
        const parsed: PlanItem[] = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter(
            (p) =>
              p &&
              p.id &&
              !p.id.startsWith('plan-seed') &&
              p.id !== 'plan-seed-1' &&
              p.id !== 'plan-seed-2' &&
              p.subjectName !== 'การตลาดดิจิทัล (Digital Marketing 301)' &&
              p.subjectName !== 'การพัฒนาเว็บแอปพลิเคชัน (Web Dev 202)'
          );
        }
      }
    } catch (e) {
      console.warn('Failed to load plans from storage:', e);
    }
    return [];
  });

  // Sync dark mode class on mount and changes
  useEffect(() => {
    if (preferences.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [preferences.darkMode]);

  // Persist preferences
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PREFS, JSON.stringify(preferences));
    } catch (e) {
      console.warn('Failed to save preferences:', e);
    }
  }, [preferences]);

  // Persist plans
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PLANS, JSON.stringify(plans));
    } catch (e) {
      console.warn('Failed to save plans:', e);
    }
  }, [plans]);

  // Handle plan creation / update
  const handleSavePlan = (newPlan: PlanItem) => {
    setPlans((prev) => [newPlan, ...prev.filter((p) => p.id !== newPlan.id)]);
    setSelectedPlanId(newPlan.id);
  };

  const handleDeletePlan = (planId: string) => {
    setPlans((prev) => prev.filter((p) => p.id !== planId));
    if (selectedPlanId === planId) {
      setSelectedPlanId('');
    }
  };

  const handleClearAllPlans = () => {
    setPlans([]);
    setSelectedPlanId('');
    try {
      localStorage.removeItem(STORAGE_KEY_PLANS);
      localStorage.removeItem('planai_study_plans_v2');
      localStorage.removeItem('planai_study_plans');
    } catch (e) {
      console.warn('Failed to clear storage:', e);
    }
  };

  const handleToggleTopicCompletion = (planId: string, topicId: string) => {
    setPlans((prev) =>
      prev.map((plan) => {
        if (plan.id !== planId) return plan;
        return {
          ...plan,
          topics: plan.topics.map((t) =>
            t.id === topicId ? { ...t, completed: !t.completed } : t
          ),
        };
      })
    );
  };

  const handleToggleBlockCompletion = (
    planId: string,
    dayNumber: number,
    blockId: string
  ) => {
    setPlans((prev) =>
      prev.map((plan) => {
        if (plan.id !== planId) return plan;
        return {
          ...plan,
          dailySchedule: plan.dailySchedule.map((day) => {
            if (day.dayNumber !== dayNumber) return day;
            return {
              ...day,
              blocks: day.blocks.map((b) =>
                b.id === blockId ? { ...b, completed: !b.completed } : b
              ),
            };
          }),
        };
      })
    );
  };

  const handleOpenWizard = (_type?: TaskType) => {
    setCurrentTab('wizard');
  };

  const handleSelectPlan = (planId: string, view: 'summary' | 'schedule') => {
    setSelectedPlanId(planId);
    setCurrentTab(view);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background text-on-surface antialiased transition-colors duration-200">
      {/* App Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        preferences={preferences}
        onUpdatePreferences={(prefs) => setPreferences((prev) => ({ ...prev, ...prefs }))}
        onOpenAccessibilityModal={() => setAccessibilityModalOpen(true)}
      />

      {/* Main App Container */}
      <main className="flex-1 w-full pt-20 max-w-[1280px] mx-auto px-4 md:px-8">
        {currentTab === 'dashboard' && (
          <DashboardView
            plans={plans}
            preferences={preferences}
            onOpenWizard={handleOpenWizard}
            onSelectPlan={handleSelectPlan}
            onDeletePlan={handleDeletePlan}
            onClearAllPlans={handleClearAllPlans}
          />
        )}

        {currentTab === 'wizard' && (
          <WizardView
            onSavePlan={handleSavePlan}
            onGoToDashboard={() => setCurrentTab('dashboard')}
            onGoToSchedule={(planId) => {
              if (planId) setSelectedPlanId(planId);
              setCurrentTab('schedule');
            }}
          />
        )}

        {currentTab === 'summary' && (
          <SummaryView
            plans={plans}
            selectedPlanId={selectedPlanId}
            onSelectPlanId={setSelectedPlanId}
            onToggleTopicCompletion={handleToggleTopicCompletion}
            onGoToSchedule={(planId) => {
              setSelectedPlanId(planId);
              setCurrentTab('schedule');
            }}
          />
        )}

        {currentTab === 'schedule' && (
          <ScheduleTimerView
            plans={plans}
            selectedPlanId={selectedPlanId}
            preferences={preferences}
            onToggleBlockCompletion={handleToggleBlockCompletion}
          />
        )}
      </main>

      {/* App Footer */}
      <Footer />

      {/* Accessibility & Settings Modal */}
      <AccessibilityModal
        isOpen={accessibilityModalOpen}
        onClose={() => setAccessibilityModalOpen(false)}
        preferences={preferences}
        onUpdatePreferences={(prefs) => setPreferences((prev) => ({ ...prev, ...prefs }))}
      />
    </div>
  );
}
