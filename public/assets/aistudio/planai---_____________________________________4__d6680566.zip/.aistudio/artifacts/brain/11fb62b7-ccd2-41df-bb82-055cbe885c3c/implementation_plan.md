# Rounded White Rectangular Frame Logo Container Plan

Wrap the PlanAI logo on the top-left Header inside a rounded white rectangular container frame (`bg-white rounded-2xl px-3 py-1.5 shadow-xs border border-subtle`) that seamlessly integrates with the website theme in both light and dark modes.

## User Review & Confirmed Decisions

> [!IMPORTANT]
> The user confirmed the following preferences:
> 1. **Styling**: Rounded white rectangular frame (`bg-white`) with a gentle subtle shadow (`shadow-xs`) and hairline border (`border border-slate-200/80 dark:border-white/20`) that makes the logo stand out clearly.
> 2. **Scope**: Applied specifically to the main logo brand lockup at the top-left Header (`Header.tsx`).

---

## 1. Overview & Core Concept

- **Goal**: Make the brand logo pop with a clean, high-contrast white rounded rectangular background frame on the top-left Header.
- **Placement**: Top-left corner of the fixed navigation header (`Header.tsx`).
- **Behavior**: Solid white background (`bg-white`) in both light and dark modes so the logo graphic and text maintain pristine contrast and legibility.

---

## 2. User Experience & Visual Design

### Header Top-Left Logo Container (`Header.tsx`)
```html
<div className="flex items-center gap-2.5 bg-white dark:bg-white text-slate-900 px-3.5 py-1.5 rounded-2xl border border-slate-200/80 dark:border-white/30 shadow-xs hover:shadow-sm transition-all duration-200">
  <img src="..." alt="PlanAI Logo" className="h-7 w-auto object-contain" />
  <span className="font-headline-sm text-base md:text-lg font-extrabold tracking-tight text-slate-900 leading-none">
    PlanAI
  </span>
</div>
```

---

## 3. Technical Architecture & Component Changes

```
┌─────────────────────────────────────────────────────────────────┐
│                           Header.tsx                            │
│                                                                 │
│  ┌─────────────────────────────────┐                            │
│  │ [ 🏷️ White Rounded Logo Frame ] │    Nav Links    [ ⚙️ ]  │
│  └─────────────────────────────────┘                            │
└─────────────────────────────────────────────────────────────────┘
```

### Proposed Changes
- **`src/components/Header.tsx`**:
  - Update the Brand Zone button element at the top-left Header.
  - Wrap the logo image and brand text in a crisp white rounded rectangular pill (`bg-white rounded-2xl px-3.5 py-1.5 border border-slate-200/80 shadow-xs`).
  - Keep `text-slate-900` on the brand text so it remains crisp and legible on the white background frame in both light and dark modes.
