import React, { useState } from 'react';
import { UserPreferences } from '../types';
import { soundHelper } from '../utils/soundHelper';

interface HeaderProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  preferences: UserPreferences;
  onUpdatePreferences: (prefs: Partial<UserPreferences>) => void;
  onOpenAccessibilityModal: () => void;
  onOpenVoiceModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  preferences,
  onUpdatePreferences,
  onOpenAccessibilityModal,
  onOpenVoiceModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleDarkMode = () => {
    const nextDark = !preferences.darkMode;
    onUpdatePreferences({ darkMode: nextDark });
    if (nextDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    soundHelper.playChime('click');
  };

  const toggleVoiceEnabled = () => {
    const nextVoice = !(preferences.voiceEnabled ?? true);
    onUpdatePreferences({ voiceEnabled: nextVoice });
    if (!nextVoice) {
      soundHelper.stopSpeech();
    } else {
      soundHelper.playChime('click', preferences.soundEnabled);
      soundHelper.speakThaiReminder('focus', preferences.voiceStyle, true);
    }
  };

  const handleVoiceTest = () => {
    if (!(preferences.voiceEnabled ?? true)) {
      toggleVoiceEnabled();
      return;
    }
    soundHelper.playChime('break', preferences.soundEnabled);
    soundHelper.speakThaiReminder('break', preferences.voiceStyle, preferences.voiceEnabled ?? true);
  };

  const navItems = [
    { id: 'dashboard', label: 'หน้าแรก', icon: 'home' },
    { id: 'wizard', label: 'อัปโหลด & วิเคราะห์', icon: 'auto_awesome' },
    { id: 'summary', label: 'สรุปผล AI', icon: 'subject' },
    { id: 'schedule', label: 'ตารางเวลา & ตัวจับเวลา', icon: 'schedule' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 w-full z-50 bg-surface-container-lowest/90 backdrop-blur-xl border-b border-subtle shadow-[0_1px_8px_rgba(0,0,0,0.04)] transition-colors">
      <div className="h-20 max-w-[1280px] mx-auto px-4 md:px-8 flex items-center justify-between gap-4">
        {/* Logo & Main Nav */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => {
              onSelectTab('dashboard');
              setMobileMenuOpen(false);
            }}
            className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-none bg-white dark:bg-white px-3.5 py-2 rounded-2xl border border-slate-200/90 dark:border-white/40 shadow-xs hover:shadow-md transition-all duration-200"
          >
            <img
              alt="PlanAI Logo"
              className="h-8 w-auto object-contain transition-transform group-hover:scale-105"
              src="https://lh3.googleusercontent.com/aida/AEtjO1XLaWFQaXcc5QljJkH59G9Epq-PUBXBVivQw4upvNCK6QJq4aLzJhAhrX-RwdLKRLvHgSQ9Qv-zeHHH_zczvoXpdJHt-gZBT0ibeX-XkrIGbLgkbqhFVS6XmGs7Y7mr7T_GS_7h7s3Mua6Tip3IyVovDBtGOVcvmgqNttcb2GKLEXgaxIKCk9ZUrKgoNFoNoEGuI9MwsEPCs_1kgMW1DN357EL4BPhPkglZP1TJvpazuzVg8L0WKE6xMffA"
            />
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1.5 bg-surface-container-low/60 p-1 rounded-full border border-subtle">
            {navItems.map((item) => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`px-4 py-2 rounded-full font-label-md text-sm transition-all duration-200 cursor-pointer ${
                    isActive
                      ? 'bg-surface-container-high text-primary font-semibold shadow-xs'
                      : 'text-on-surface-variant hover:text-on-surface hover:bg-surface-container-low'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-2.5">
          {/* Control Utility Buttons: Dark Mode, Gear Voice Settings, Accessibility */}
          <div className="flex items-center bg-surface-container-low rounded-full px-2 py-1 gap-1 border border-subtle shadow-xs">
            {/* Dark Mode Toggle */}
            <button
              onClick={toggleDarkMode}
              className="p-1.5 rounded-full text-on-surface-variant hover:text-primary transition-colors flex items-center justify-center cursor-pointer"
              title={preferences.darkMode ? 'สลับเป็นโหมดสว่าง' : 'สลับเป็นโหมดมืด (Dark Mode)'}
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">
                {preferences.darkMode ? 'dark_mode' : 'light_mode'}
              </span>
            </button>

            {/* Single Gear Settings Button for AI Voice Settings */}
            <button
              onClick={onOpenVoiceModal}
              className="p-1.5 rounded-full text-on-surface-variant hover:text-primary transition-colors flex items-center justify-center cursor-pointer"
              title="ตั้งค่าเสียง AI ผู้ช่วย"
              aria-label="ตั้งค่าเสียง AI ผู้ช่วย"
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">settings</span>
            </button>

            {/* Accessibility & Eye Health Modal Button */}
            <button
              onClick={onOpenAccessibilityModal}
              className="p-1.5 rounded-full text-on-surface-variant hover:text-primary transition-colors flex items-center justify-center cursor-pointer"
              title="การเข้าถึงและความช่วยเหลือ (ถนอมสายตา/กฎ 20-20-20)"
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">accessibility_new</span>
            </button>
          </div>

          {/* User Profile */}
          <div className="flex items-center gap-2.5 pl-1">
            <img
              alt="Profile"
              className="w-9 h-9 rounded-full object-cover ring-2 ring-primary/20"
              src={preferences.avatarUrl}
            />
            <div className="hidden sm:flex flex-col text-left">
              <span className="font-label-md text-sm text-on-surface leading-tight font-semibold">
                {preferences.userName}
              </span>
              <span className="font-label-sm text-xs text-on-surface-variant leading-tight">
                {preferences.userRole}
              </span>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl bg-surface-container-low text-on-surface hover:text-primary transition-colors cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            <span className="material-symbols-outlined text-[22px]">
              {mobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-surface-container-lowest border-b border-subtle px-4 py-4 flex flex-col gap-2 shadow-lg animate-fadeIn">
          {navItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl font-label-md text-sm transition-all cursor-pointer ${
                  isActive
                    ? 'bg-surface-container-high text-primary font-bold'
                    : 'text-on-surface-variant hover:bg-surface-container-low'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">{item.icon}</span>
                <span>{item.label}</span>
              </button>
            );
          })}

          <div className="pt-3 border-t border-subtle flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenVoiceModal();
                setMobileMenuOpen(false);
              }}
              type="button"
              className="w-full py-3 px-4 rounded-xl bg-surface-container-low hover:bg-surface-container text-on-surface font-bold text-xs md:text-sm flex items-center justify-between transition-colors cursor-pointer border border-subtle"
            >
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-primary text-[20px]">settings</span>
                <span>ตั้งค่าเสียง AI ผู้ช่วย</span>
              </div>
              <span className="material-symbols-outlined text-[18px] text-on-surface-variant">chevron_right</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
