// Sound synthesis & Voice reminder utility for PlanAI

class SoundHelper {
  private audioCtx: AudioContext | null = null;

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  // Stop speech synthesis immediately
  stopSpeech() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // Fallback
      }
    }
  }

  // Play a pleasant chime for timer start/stop/break
  playChime(type: 'start' | 'break' | 'complete' | 'click' = 'complete', enabled: boolean = true) {
    if (!enabled) return;
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;

      if (type === 'start') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.25);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      } else if (type === 'break') {
        // Soft meditative tone
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.15); // E5
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
        osc.start(now);
        osc.stop(now + 0.6);
      } else if (type === 'complete') {
        // Uplifting major triad
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.setValueAtTime(739.99, now + 0.18); // F#5
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
        osc.start(now);
        osc.stop(now + 0.8);
      } else {
        // Quick subtle click
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, now);
        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
        osc.start(now);
        osc.stop(now + 0.05);
      }
    } catch {
      // Audio autoplay policy fallback
    }
  }

  // Voice reminder using browser SpeechSynthesis in Thai
  speakThaiReminder(
    messageType: 'break' | 'congrats' | 'focus' | 'sample',
    style: 'friend' | 'mentor' | 'formal' = 'friend',
    enabled: boolean = true
  ) {
    if (!enabled) {
      this.stopSpeech();
      return;
    }
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    let text = '';
    if (messageType === 'sample') {
      const samples = {
        friend: [
          'พร้อมลุยอ่านหนังสือด้วยกันหรือยัง! จะจับเวลาแล้วนะ!',
          'วันนี้มาตั้งใจอ่านหนังสือกันนะเพื่อน!',
          'ยินดีต้อนรับนะ! วันนี้มาเต็มที่อีกวันกัน!',
        ],
        mentor: [
          'สวัสดีครับน้อง เช็คปฏิทินของวันนี้ด้วยนะ',
          'ตั้งใจอ่านหนังสือนะครับ พี่คอยเป็นกำลังใจให้เสมอ',
          'รอบนี้อ่านทีละหัวข้อ น้องทำได้แน่นอนครับ',
        ],
        formal: [
          'ยินดีต้อนรับสู่ระบบจัดตารางเวลา PlanAI ครับ',
          'ขอให้ท่านมีความสุขและประสบความสำเร็จในการทำตามที่วางแผนไว้นะครับ',
          'ระบบพร้อมช่วยเหลือการจัดตารางเวลาของท่านแล้วครับ',
        ],
      };
      const list = samples[style] || samples.friend;
      text = list[Math.floor(Math.random() * list.length)];
    } else if (messageType === 'break') {
      if (style === 'friend') {
        text = 'ฮัลโหล! อ่านมาสักพักแล้วนะ พักสายตา ดื่มน้ำสักแก้ว แล้วค่อยลุยต่อนะเพื่อน';
      } else if (style === 'mentor') {
        text = 'น้องครับ ถึงเวลาพักสายตาแล้วนะ หลับตาสัก 2 นาที สมองจะได้แล่นครับ';
      } else {
        text = 'ระบบขอแนะนำให้ท่านพักสายตาและยืดเหยียดร่างกายเพื่อสุขภาพที่ดี';
      }
    } else if (messageType === 'congrats') {
      if (style === 'friend') {
        text = 'สุดยอดเลย! เก็บไปได้อีกหนึ่งหัวข้อแล้วนะ พักผ่อนให้สบายใจเลย';
      } else if (style === 'mentor') {
        text = 'เก่งมากครับน้อง วันนี้ก้าวหน้าตามแผนได้ดีมาก พักผ่อนให้พอนะครับ';
      } else {
        text = 'ขอแสดงความยินดี คุณได้ทำตามเป้าหมายประจำช่วงเวลานี้สำเร็จแล้ว';
      }
    } else {
      if (style === 'friend') {
        text = 'มาเริ่มลุยกันเลย! สู้ๆ นะ มีสมาธิเต็มที่เพื่อน';
      } else if (style === 'mentor') {
        text = 'พร้อมแล้วเริ่มกันเลยครับน้อง ค่อยๆ ทำทีละขั้น ไม่ต้องกดดัน';
      } else {
        text = 'เริ่มต้นช่วงเวลาโฟกัส ขอให้ตั้งใจอย่างเต็มความสามารถ';
      }
    }

    try {
      this.stopSpeech();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'th-TH';
      utterance.rate = 1.0;
      utterance.pitch = style === 'friend' ? 1.05 : style === 'mentor' ? 0.95 : 1.0;

      // Find Thai voice if available
      const voices = window.speechSynthesis.getVoices();
      const thaiVoice = voices.find((v) => v.lang.includes('th') || v.lang.includes('TH'));
      if (thaiVoice) {
        utterance.voice = thaiVoice;
      }

      window.speechSynthesis.speak(utterance);
    } catch {
      // Speech synthesis fallback
    }
  }
}

export const soundHelper = new SoundHelper();
